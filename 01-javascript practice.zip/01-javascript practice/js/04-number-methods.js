/*-------------------------------------------------------------
        1-Covert number Into String 
---------------------------------------------------------------*/
//toString() method;
var myStringNum = 22;
var modifedNumber = myStringNum.toString(); // "22"
console.log(typeof modifedNumber)
console.log(modifedNumber)
/*-------------------------------------------------------------
        2-Covert string Into number 
---------------------------------------------------------------*/
//covert string into number;

//method-1 : (Number(valueToBeConverted)) both integer and decimal value can be converted,


// var stringToNum = "124";
var stringToNum = "124.6756";
var newNymb = Number(stringToNum)
console.log(stringToNum)
console.log(newNymb)
console.log(typeof stringToNum)
console.log(typeof newNymb)
Number(true);          // returns 1
Number(false);         // returns 0
Number("10");          // returns 10
Number("  10");        // returns 10
Number("10  ");        // returns 10
Number(" 10  ");       // returns 10
Number("10.33");       // returns 10.33
Number("10,33");       // returns NaN
Number("10 33");       // returns NaN
Number("John");        // returns NaN

//method-2:parseInt(valueToBeConverted) application only for integer number nor for decimal.

// var numberEx1 = "124" // can change
var numberEx1 = "124.134" // can't change output will be only integer number i.e only 124

var convertNumberEx1 = parseInt(numberEx1)

console.log(numberEx1)
console.log(typeof numberEx1)
console.log(convertNumberEx1)
console.log(typeof convertNumberEx1)

parseInt("-10");        // returns -10
parseInt("-10.33");     // returns -10
parseInt("10");         // returns 10
parseInt("10.33");      // returns 10
parseInt("10 20 30");   // returns 10
parseInt("10 years");   // returns 10
parseInt("years 10");   // returns NaN 

//method-3:parseFloat(valueToBeConverted) application only for integer number nor for decimal.
parseFloat("10");        // returns 10
parseFloat("10.33");     // returns 10.33
parseFloat("10 20 30");  // returns 10
parseFloat("10 years");  // returns 10
parseFloat("years 10");  // returns NaN

/*-------------------------------------------------------------
        2-Fixed The Number 
---------------------------------------------------------------*/

// method-1: toFixed()

let numTofixed = 9.6562345512134;
console.log(numTofixed.toFixed()) // output 10
console.log(numTofixed.toFixed(1)) // output 9.7
console.log(numTofixed.toFixed(2)) // output 9.66
console.log(numTofixed.toFixed(3)) // output 9.656
console.log(numTofixed.toFixed(4)) // output 9.6562
console.log(numTofixed.toFixed(5)) // output 9.65623
console.log(numTofixed.toFixed(6)) // output  9.656235
console.log(numTofixed.toFixed(7)) // output 9.6562346

/*-------------------------------------------------------------
        2-pricision The Number 
---------------------------------------------------------------*/

// method-1: toFixed()

let numToprecise = 9.6562345512134;
console.log("pre", numToprecise.toPrecision()) // output 10
console.log(numToprecise.toPrecision(1)) // output 9.7
console.log(numToprecise.toPrecision(2)) // output 9.66
console.log(numToprecise.toPrecision(3)) // output 9.656
console.log(numToprecise.toPrecision(4)) // output 9.6562
console.log(numToprecise.toPrecision(5)) // output 9.65623
console.log(numToprecise.toPrecision(6)) // output  9.656235
console.log(numToprecise.toPrecision(7)) // output 9.6562346
