/*
= is the assignment operator.
It assigns the value of the right side to the left side.
In this case, it assigns the value of the element with the id "myName" to the variable myName.
*/
console.log(myName);

// Language: javascript
//Data Types:
// String   - "Hello World",'Hello World',`Hello World`.
// Number   - 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
// Boolean  - true, false
// Array    - [1, 2, 3, 4, 5]
// Object   - {name: "Naufil", age: 25}
// Null     - null
// Undefined- undefined
// Function - function myFunction(){}
// Symbol   - Symbol("Naufil")
// Date     - new Date()
// Regular Expression - /\d+/
// Math     - Math.PI, Math.round, Math.ceil, Math.floor, Math.abs, Math.pow, Math.sqrt, Math.min, Math.max, Math.random
// String   - "Hello World".length, "Hello World".toUpperCase(), "Hello World".toLowerCase(), "Hello World".charAt(0), "Hello World".indexOf("o"), "Hello World".lastIndexOf("o"), "Hello World".substring(0, 5), "Hello World".slice(0, 5), "Hello World".replace("Hello", "Goodbye"), "Hello World".split(" "), "Hello World".trim(), "Hello World".concat(" ", "Naufil")

/*-----------------------------------------------------------------------
                            1-string
-------------------------------------------------------------------------*/
var myName = document.getElementById("myName");
var changeName = "My Name rockstar";
// myName.innerHTML = "My Name is Naufil"; // double comma
// myName.innerHTML = 'My Name is Naufil'; // single comma
// myName.innerHTML = `My Name is Naufil`; // back tick
myName.innerHTML = changeName;
console.log(myName.innerHTML)

var fullName = document.getElementById("fullName");
var firstName = "Momin Naufil";
var lastName = "Iqbal Ahmed";
// fullName.innerHTML = "My Name Is " + firstName + " " + lastName;
fullName.innerHTML = `your name is  ${firstName} ${lastName}`; //string me bhi de sakte hai

console.log(fullName.innerHTML);
console.log(typeof changeName)
console.log(typeof fullName)

/*------------------------------------------------------------------------------------- */
/*-----------------------------------------------------------------------
                            2-Number
-------------------------------------------------------------------------*/
var myNumber = 4
var myNewNumber = 4.5

console.log(typeof myNumber)
console.log(typeof myNewNumber)



/*-----------------------------------------------------------------------
                            3-Boolean
-------------------------------------------------------------------------*/
var myBool = true; // either true or false.
console.log(typeof myBool)

/*-----------------------------------------------------------------------
                            4-Array
-------------------------------------------------------------------------*/
// collection of data stored in array
var myFlat = ["hall", "kitchen", 2, true,]
console.log(typeof myFlat)

/*-----------------------------------------------------------------------
                            5-Object
-------------------------------------------------------------------------*/
// evrything in real life is object.

var car = {
    companyName: "",
    carName: "",
    model: "",
    drive: "",
    enginePower: "",
    color: ""
}
console.log(typeof car)
/*-----------------------------------------------------------------------
                            6-Array of Object
-------------------------------------------------------------------------*/
// collection of data with their key and value
var amazonMobileProducts = [
    { id: 1, brand: "MI", model: "redmi Note 10", color: "black" },
    { id: 2, brand: "Samsung", model: "redmi Note 10", color: "black" },
    { id: 3, brand: "Realme", model: "redmi Note 10", color: "black" },
    { id: 4, brand: "Nokia", model: "redmi Note 10", color: "black" },
    { id: 5, brand: "Honor", model: "redmi Note 10", color: "black" },
    { id: 6, brand: "Apple", model: "redmi Note 10", color: "black" },
]

console.log(amazonMobileProducts)

var newAmazonProducts = [
    {
        id: 1, brand: "MI", models: [
            { modelId: "ER1", modelName: "Redmi Note 10pro", color: ["red", "blue", "black", "white"] },
            { modelId: "ER2", modelName: "Redmi Note 11pro", color: ["red", "blue", "black", "white"] },
            { modelId: "ER3", modelName: "Redmi Note 12pro", color: ["red", "blue", "black", "white"] }]
    },
    {
        id: 2, brand: "oneplus", models: [
            { modelId: "ps1", modelsName: "OnePlus 3", color: ["black", "blue", "gray"] },
            { modelId: "ps2", modelsName: "OnePlus 3T", color: ["black", "blue", "gray"] },
            { modelId: "ps3", modelsName: "OnePlus 5", color: ["black", "blue", "gray"] },
            { modelId: "ps4", modelsName: "OnePlus 5T", color: ["black", "blue", "gray"] }

        ]
    }
]
console.log("newAmazonProducts", newAmazonProducts)

/*-----------------------------------------------------------------------
                            6-Null
-------------------------------------------------------------------------*/

var myNull = null;
console.log(typeof myNull);

/*-----------------------------------------------------------------------
                            6-Undefined
-------------------------------------------------------------------------*/
var myUndef = undefined
console.log(typeof myUndef);