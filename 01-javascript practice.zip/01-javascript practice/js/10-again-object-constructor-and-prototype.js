/*---------------------------------------------------------------------------
        1-Simple Object In Class Way
-----------------------------------------------------------------------------*/

function PersonData(fName, lName, age) {
    this.fName = fName;
    this.lName = lName;
    this.age = age;
}

var personData = new PersonData('Saif', "Momin", 26);
var samName = new PersonData("Sameer", "Shaikh", 25)

console.log("personData", personData)
console.log("samName", samName.fName, samName.lName, samName.age)

/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */

/*---------------------------------------------------------------------------
        2-Simple Object In Class Way add new property to existing classs
-----------------------------------------------------------------------------*/
function PersonDataOne(fName, lName, age) {
    this.fName = fName;
    this.lName = lName;
    this.age = age;
}

var personDataOne = new PersonDataOne('Saif', "Momin", 26);
personDataOne.qualification = "Graduate"
console.log("personDataOne", personDataOne)

/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */



/*---------------------------------------------------------------------------
        3-Simple Object In Class Way with Method
-----------------------------------------------------------------------------*/
function PersonDataTwo(fName, lName, age) {
    this.fName = fName;
    this.lName = lName;
    this.age = age;

    this.fullName = function () {
        return this.fName + " " + this.lName;
    }
}

PersonDataTwo.prototype.qualification = "graduate"
var personDataTwo = new PersonDataTwo('Nazim', "Ansari", 23);
console.log("personDataTwo", personDataTwo.fullName(), personDataTwo.age, personDataTwo.qualification)
console.log("personDataTwo", personDataTwo.qualification)


/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */