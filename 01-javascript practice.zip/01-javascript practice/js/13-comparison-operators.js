/*---------------------------------------------------------------------------
        1- (==) check values but not check type
-----------------------------------------------------------------------------*/
var x = 10
var y = "10"
console.log(x == y) // true
if (x == y) {
    console.log("saif1") // output
} else {
    console.log("sameer1")
}
var x = 10
var y = "11"
console.log(x == y) // false
if (x == y) {
    console.log("saif2")
} else {
    console.log("sameer2") // output
}

/*---------------------------------------------------------------------------
        2- (===) check values and check type
-----------------------------------------------------------------------------*/
var x = 10
var y = "10"
console.log(x === y) // false
if (x === y) {
    console.log("saif3")
} else {
    console.log("sameer3") // output
}
var x = 10
var y = "11"
console.log(x === y) // false
if (x === y) {
    console.log("saif4")
} else {
    console.log("sameer4") // output
}

var x = 10
var y = 10
console.log(x === y) // true
if (x === y) {
    console.log("saif5") // output
} else {
    console.log("sameer5")
}
var x = 10
var y = 11
console.log(x === y) // false
if (x === y) {
    console.log("saif6")
} else {
    console.log("sameer6") // output
}
/*---------------------------------------------------------------------------
        3- (!=) == ka ulta
-----------------------------------------------------------------------------*/
var x = 10
var y = "10"
console.log(x != y) // false
if (x != y) {
    console.log("saif7")
} else {
    console.log("sameer7") // output
}
var x = 10
var y = "11"
console.log(x != y) // true
if (x != y) {
    console.log("saif8") // output
} else {
    console.log("sameer8")
}
/*---------------------------------------------------------------------------
        4- (!==) === ka ulta first check type then check value [phir ulta kardega]
-----------------------------------------------------------------------------*/
var x = 10
var y = "10"
//type diffrenet - false
// value same  - true
console.log(x !== y) // output = true
if (x !== y) {
    console.log("saif9")// output
} else {
    console.log("sameer9")
}
var x = 10
var y = "11"
//type diffrent - false
// value differnet -false
console.log(x !== y) // output = true
if (x !== y) {
    console.log("saif10") // output
} else {
    console.log("sameer10")
}

var x = 10
var y = 10
//type same -true
// value same - true
console.log(x !== y) // false
if (x !== y) {
    console.log("saif11")
} else {
    console.log("sameer11") // output
}
var x = 10
var y = 11
//type same -true
//value not same - false
console.log(x !== y) // true
if (x !== y) {
    console.log("saif12")
} else {
    console.log("sameer12") // output
}

/*---------------------------------------------------------------------------
        5- (<) less than
-----------------------------------------------------------------------------*/
var x = 10
var y = 10
console.log(x < y) // false
if (x < y) {
    console.log("saif13")
} else {
    console.log("sameer13") // output
}
var x = 10
var y = 11
console.log(x < y) // true
if (x < y) {
    console.log("saif14") // output
} else {
    console.log("sameer14")
}
/*---------------------------------------------------------------------------
        6- (<=) less than and equal to
-----------------------------------------------------------------------------*/
var x = 10
var y = 10
console.log(x <= y) // true
if (x <= y) {
    console.log("saif15")// output
} else {
    console.log("sameer15")
}
var x = 10
var y = 11
console.log(x <= y) // true
if (x <= y) {
    console.log("saif16") // output
} else {
    console.log("sameer16")
}
/*---------------------------------------------------------------------------
        7- (>) Greater than
-----------------------------------------------------------------------------*/
var x = 10
var y = 10
console.log(x > y) // false
if (x > y) {
    console.log("saif17")
} else {
    console.log("sameer17") // output
}
var x = 11
var y = 10
console.log(x > y) // true
if (x > y) {
    console.log("saif18") // output
} else {
    console.log("sameer18")
}
/*---------------------------------------------------------------------------
        8- (>=) greater than and equal to
-----------------------------------------------------------------------------*/
var x = 10
var y = 10
console.log(x >= y) // true
if (x >= y) {
    console.log("saif19")// output
} else {
    console.log("sameer19")
}
var x = 11
var y = 10
console.log(x >= y) // true
if (x >= y) {
    console.log("saif20") // output
} else {
    console.log("sameer20")
}
/*---------------------------------------------------------------------------
        9- conditional (ternary opertor) if else ka alternative most imprtant
        condition?(true yaha code chalega):false hai to yaha code chalega
-----------------------------------------------------------------------------*/
var x = 10
var y = 10
console.log(x > y) // false
x > y ? console.log("saif21") : console.log("sameer21")
var x = 11
var y = 10
console.log(x > y) // true
x > y ? console.log("saif22") : console.log("sameer22")
/*---------------------------------------------------------------------------
        9- (||) or or operator dono me se ek bhi condition satisfy hai to true nhi to false
-----------------------------------------------------------------------------*/
var x = 6
var y = 10
console.log(x < 5 || y < 11) //true
if (x < 5 || y < 11) {
    console.log("saif23") // output
} else {
    console.log("sameer23");
}
console.log(x < 7 || y < 11) //true
if (x < 7 || y < 11) {
    console.log("saif24") // output
} else {
    console.log("sameer24");
}
console.log(x < 4 || y < 9) //false
if (x < 4 || y < 9) {
    console.log("saif25")
} else {
    console.log("sameer25"); // output
}

/*---------------------------------------------------------------------------
        9- (&&) and and operator dono condition true honi hi chahiye to true dono se agar ek bhi true hue to false
-----------------------------------------------------------------------------*/
//dono condition satsfies honi hi chahiye
var x = 6
var y = 10
console.log(x < 7 && y < 11) //true
if (x < 7 && y < 11) {
    console.log("saif27") // output
} else {
    console.log("sameer27");
}
console.log(x < 5 && y < 11) //false
if (x < 5 && y < 11) {
    console.log("saif26")
} else {
    console.log("sameer26");// output
}

console.log(x < 4 && y < 9) //false
if (x < 4 && y < 9) {
    console.log("saif28")
} else {
    console.log("sameer28"); // output
}
/*---------------------------------------------------------------------------
        9- (!) not
-----------------------------------------------------------------------------*/
var saif = !true
console.log(saif) // output false