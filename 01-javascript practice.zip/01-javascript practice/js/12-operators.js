var myNumber = 0; // global variables
var myDecNumber = 10; //global variables
var incBtn = document.getElementById("inc");
var decBtn = document.getElementById("dec");
incBtn.addEventListener("click", function () {
    // console.log(myNumber + 1) // doesnot work

    // method 1 : increment 
    // console.log("incremet 1", myNumber++) // start from 0

    //method 2 : incrememnet
    // myNumber = myNumber + 1;
    // console.log(myNumber) //start from 1
    // or
    // myNumber += 1;
    // console.log("incremet 1", myNumber) // start from 1
})

decBtn.addEventListener("click", function () {

    //method 1 : decrement
    // console.log("dec", myDecNumber--) // start from 10

    //method 2 :decremenet 
    myDecNumber = myDecNumber - 1; // decremnet from 9
    // myDecNumber = myDecNumber - 2;
    // or
    // myDecNumber -= 2
    // debugger
    console.log("dec", myDecNumber)
})