var personData = {
    fName: "saif",
    age: 26,
    qulification: "graduate"
}
console.log(personData.fName)
for (personDataKey in personData) {
    console.log(personData[personDataKey])

}

var personArray = Object.values(personData);
// console.log(personArray)

//koi bhi loop chala do