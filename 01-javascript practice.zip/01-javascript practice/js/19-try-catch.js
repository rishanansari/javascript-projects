try {
    myFn()
    console.log("try")
} catch (error) {
    console.log(error)
}

function myFn() {

}