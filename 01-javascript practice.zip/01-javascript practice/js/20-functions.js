//declare/call/invoke



/*------------------------------------------------------------------------------------------------
            there Are two types of function
            1-kaam karte ek ke baad execute hote hai isme bhi parameter bhej skte hai koi masla nhi hai.
            2-kuch kaam karke uski value return kar dete hai usko hum ek variable me store karke use kar skte hai. Isme parameter bhejn hota hai
-------------------------------------------------------------------------------------------*/
/*------------------------------------------------------------------------------------------------
            1-Type one sirf kaam kar rahe hai ek ke baad ek code execute kar rahe hai line by line
            kuch bhi value return nhi kar rahe  hai
-------------------------------------------------------------------------------------------*/

//declare without paramter
// nazimFn()
// nazimFn() //do baar kaam karega
// sameerFn()



// define function
// function sameerFn() {
//     console.log("sameer subha uthta hai");
//     console.log("Nashta karta hai");
//     console.log("Kaam par jata hai");
// }

// function nazimFn() {
//     console.log("nazim late uthta hai");
//     console.log("Mohaddis se milne jata hai");
//     console.log("uske Saath Chai pita hai");
// }

// //declare with parameter
// let fName = "sameer"
// saifFn(fName)

// function saifFn(name) {
//     console.log(name)

// }

// let personExcersice = {
//     personName: "sameer",
//     morningTime: "09:30 AM",
//     travell: "thane",
//     officeName: "IT solutions"
// }

// sameerNewFn(personExcersice.personName, personExcersice.morningTime, personExcersice.travell, personExcersice.officeName); //upar ek ek let me means ek hi objt me sab details hai isliye aisa kiye.


// let personName = "Nazim";
// let morningTime = "08:00 AM"
// let travel = "mumbai";
// let officName = "Pyramid IT Solution"
// sameerNewFn(personName, morningTime, travel, officName) //yaha sab alag alag let me hai isliye aisa


// sameerNewFn("saif", "11:00 AM", "Andheri", "Adapty")





// function sameerNewFn(name, time, travel, office) {

//     console.log(`${name} Subha ${time} baje uth jata hai`)
//     console.log(`${name} bahot takleef se ${travel} office jata hai`)
//     console.log(`${name} ${office} me kaam karta hai`)

// }

/*------------------------------------------------------------------------------------------------
            2-Type Two special functions bolte hai qki ye kuch kaam karte hai aur kaam karne baad value ko return kar dete hai
-------------------------------------------------------------------------------------------*/

//example ek collge hai uske result me % nikalnaa hai




let ObtainedValue = 780;
let totalValue = 1000;

let output = getPercentage(ObtainedValue, totalValue)
console.log("output", output);
// uper ki 4 line sirf samjhne k liye hai



function getPercentage(obtValue, total) {
    let percentage = (obtValue / total) * 100
    return percentage

}

function resultDeclarationWithName(name, percentage) {
    return `Student ${name} got ${percentage}`
}

const studentsData = [
    { id: 1, studentName: "Saif", obtainMarkes: 674, totalMarkes: 800 },
    { id: 2, studentName: "Sameer", obtainMarkes: 500, totalMarkes: 800 },
    { id: 3, studentName: "Nazim", obtainMarkes: 724, totalMarkes: 800 },
    { id: 4, studentName: "Naufil", obtainMarkes: 678, totalMarkes: 800 },
    { id: 5, studentName: "Bilal", obtainMarkes: 400, totalMarkes: 800 },
    { id: 6, studentName: "Tawheed", obtainMarkes: 225, totalMarkes: 800 },
    { id: 7, studentName: "Mohaddis", obtainMarkes: 722, totalMarkes: 800 },
]

for (let i = 0; i < studentsData.length; i++) {
    let student = studentsData[i]
    let percentage = getPercentage(student.obtainMarkes, student.totalMarkes)
    let resultWithName = resultDeclarationWithName(student.studentName, percentage)
    console.log("resultWithName", resultWithName)
}

