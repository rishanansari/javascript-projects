/*---------------------------------------------------------------------------
        1-Simple Class
-----------------------------------------------------------------------------*/

class PersonData {
    constructor(fName, lName, age) {
        this.fName = fName;
        this.lName = lName;
        this.age = age;
    }
}

var personData = new PersonData("Momin", "Saif", 26);
// var personData = new PersonData("Momin", "Saif", 26);
// var personData = new PersonData("Momin", "Saif", 26);
// var personData = new PersonData("Momin", "Saif", 26);
// var personData = new PersonData("Momin", "Saif", 26);
var fullName = personData.fName + " " + personData.lName
var age = `I am ${this.personData.age} old`
console.log(fullName);
console.log(age);

/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */


/*---------------------------------------------------------------------------
        2-Simple Class with Methods
-----------------------------------------------------------------------------*/

class PersonDataOne {
    constructor(fName, lName, age) {
        this.fName = fName;
        this.lName = lName;
        this.age = age;
    }
    getFullName() {
        return this.fName + " " + this.lName
    }
    increasedPersonAge(iAgeValue, y) {
        return this.age + iAgeValue - y;

    }
}

var newPersonData = new PersonDataOne("Sameer", "Shaikh", 25)
var fullName = newPersonData.getFullName();
var increasedAge = newPersonData.increasedPersonAge(20, 40)
console.log("increased age", fullName, increasedAge)
/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */

/*---------------------------------------------------------------------------
        3-Class Inheritence
    
        - already ek parent class hai jisme variables declared hai so agar hume
        agar parent class ke variables ko access karna hai to hum extend krenge class.
        hume variables ko super() method ke andar dalna hoga.
        class ParentClass {
            constructor(){

            }
        }  
        eg :- class SomeClass extend ParentClass {
            constructor(){
                    super(varable1,variable2)
            }
                    
        }
-----------------------------------------------------------------------------*/

class PersonNormalData {
    constructor(fName, lName) {
        this.fName = fName
        this.lName = lName
    }
    getFullName() {
        return `My FullName Is ${this.fName} ${this.lName}`
    }
}

class PersonAge extends PersonNormalData {
    constructor(fName, lName, age) {
        super(fName, lName)
        this.age = age

    }
    // getFullNameWithAge() {
    //     return `My FullName Is ${this.fName} ${this.lName} And My Age Is ${this.age}`
    // }
    getFullNameWithAge() {
        return `${this.getFullName()} And My Age Is ${this.age}`
    }
}

var perosnDataWithAge = new PersonAge("Nazim", "Ansari", 22);
var salmanDataWithAge = new PersonAge("Salman", "Khan", 58);
var sharukhDataWithAge = new PersonAge("Sharukh", "Khan", 55);
var AmirDataWithAge = new PersonAge("Amir ", "Khan", 56);
console.log("extend", perosnDataWithAge.getFullNameWithAge())
console.log(salmanDataWithAge.getFullNameWithAge())
console.log(sharukhDataWithAge.getFullNameWithAge())
console.log(AmirDataWithAge.getFullNameWithAge())
