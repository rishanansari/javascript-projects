/*------------------------------------------------------------------------
 loop meaning
 continuosly chalna jab tak uski condition reach nhi ho jaati

 loop ke bahot saare types hote hai
  kuch loops number par run hote hai
  kuch loops array par run hote
  kuch loops object par run hote

  index means number
  values means data
  1-for loop (run on index) applicable- array.
  2-for in (run on object keys) applicable -object
  3-forEach (run on values and index) applicable-array
  4-for of (run on values) applicable-array
  5-while and do-while loop run on conditions based
  6-map method sabse fast

  conslusion
  array - for loop,forEach loop,for of loop.
  object - for in loop.
 -------------------------------------------------------------------------*/


/*------------------------------------------------------------------------
             1-Basic undesrtanding of loop.
             contoniously chalte jana jab tak condition reach nhi ho jaati.
-------------------------------------------------------------------------*/
// for (let i = 0; i <= 10; i++) {
//     // console.log(i) //i++ means increment by one start from 0
// }
// for (let i = 0; i <= 10; i += 2) {
//     console.log(i) //i += means increment by two start from 0
// }
// for (let i = 0; i <= 10; i++) {
//     if (i < 2) {
//         console.log("saif")
//     } else {
//         // console.log("sameer");
//     }
// }

//loop aaya hai array and object ke liye
// var arr = ["bilal", "naufil", "sameer", "nazim", "saif"]
// // console.log(arr[0]);
// // console.log(arr[1]);
// console.log(arr[2]);
// // console.log(arr[3]);
// // console.log(arr[4]);
// console.log(arr.length);

// for (let i = 0; i < arr.length; i++) {
//     console.log(i)
//     console.log(arr[i])
// }
