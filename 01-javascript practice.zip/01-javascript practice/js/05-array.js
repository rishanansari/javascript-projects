/*--------------------------------------------------------------------
    collection of data is called array
--------------------------------------------------------------------*/
var selectedFrnd = document.getElementById('frndName')
var friendsCircle = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
console.log(friendsCircle)
console.log(friendsCircle[0])
console.log(friendsCircle[1])
console.log(friendsCircle[2])
console.log(friendsCircle[3])
console.log(friendsCircle[4])
console.log(friendsCircle[5] = "tawheed")
console.log(friendsCircle) // mohaddis change with tawheed
selectedFrnd.innerHTML = friendsCircle