/*-------------------------------------------------------------
        1-Convert Array into string
---------------------------------------------------------------*/

//toString()
var friendsCircle = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
var convtInString = friendsCircle.toString()
console.log(friendsCircle)
console.log(typeof friendsCircle)
console.log(convtInString)
console.log(typeof convtInString)

// join method - also convert in array into string 

var friendsCircle1 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
// var convtInString1 = friendsCircle1.join()
var convtInString1 = friendsCircle1.join(" ")
// var convtInString1 = friendsCircle1.join("|")
console.log(friendsCircle1)
console.log(typeof friendsCircle1)
console.log("join method:", convtInString1)
console.log(typeof convtInString1)

// Note: split method convert string into array
/*-------------------------------------------------------------
        2-length
---------------------------------------------------------------*/
var friendsCircle2 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
console.log("lenght:", friendsCircle2.length)

/*-------------------------------------------------------------
        3-pop and push method remove and add at the last element of array
---------------------------------------------------------------*/

// method-1 : pop() remove last element of array.
var friendsCircle3 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
var removeLastEmemnt = friendsCircle3.pop() // mohaddis will be removed
console.log("pop:", friendsCircle3)

// method-2 : push(valuetoBeAdded) add element at the last of array.
var friendsCircle4 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
var addTawheed = friendsCircle4.push("tawheed");

console.log("push:", friendsCircle4)

/*-------------------------------------------------------------------------------
        4-shift and unshift method remove and add at the fist element of array
--------------------------------------------------------------------------*/
// method-1 : shift() remove start element of array.
var friendsCircle5 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
var removefisrtEmemn = friendsCircle5.shift() // sameer will be removed
console.log("shift:", friendsCircle5)

// method-2 : unshift() add new element at the start of array.
var friendsCircle6 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
var addnewTawheed = friendsCircle6.unshift("tawheed");

console.log("unshift:", friendsCircle6)

/*-------------------------------------------------------------------------------
        4-splice method add and remove elements of array anyway.

        const fruits = ["Banana", "Orange", "Apple", "Mango"];
        fruits.splice(2, 0, "Lemon", "Kiwi");


The first parameter (2) defines the position where new elements should be added (spliced in).

The second parameter (0) defines how many elements should be removed.

The rest of the parameters ("Lemon" , "Kiwi") define the new elements to be added.
-----------------------------------------------------------------------------*/
var friendsCircle7 = ["mango", "apple", "kiwi", "orange", "banana", "watermelon"]
var tawheedBetween = friendsCircle7.splice(2, 0, "pineapple");// ['mango', 'apple','pineapple', 'kiwi', 'orange', 'banana', 'watermelon']
// var tawheedBetween = friendsCircle7.splice(2, 2, "pineapple"); // ['mango', 'apple', 'pineapple', 'banana', 'watermelon']
// var tawheedBetween = friendsCircle7.splice(2); //  ['mango', 'apple']
// var tawheedBetween = friendsCircle7.splice(2, 3); //  ['mango', 'apple', 'watermelon']
console.log("splice:", friendsCircle7)

/*-------------------------------------------------------------------------------
        5-slice  method slices out a piece of an array into a new array..
-----------------------------------------------------------------------------*/
var friendsCircle8 = ["sameer", "saif", "nazim", "bilal", "naufil", "mohaddis"]
// var sliceOut = friendsCircle8.slice(2)//['nazim', 'bilal', 'naufil', 'mohaddis']
var sliceOut = friendsCircle8.slice(1, 5)//['saif', 'nazim', 'bilal','naufil']
console.log("slice:", sliceOut)