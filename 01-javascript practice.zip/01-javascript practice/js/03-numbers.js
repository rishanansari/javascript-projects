var x = 10;
var y = 5;
// var sumNumber = x + y;
// var sumNumber = x - y;
// var sumNumber = x * y;
var sumNumber = x / y;
// var sumNumber = x % y;

console.log(sumNumber)
console.log("NaN", 100 / "apple")

