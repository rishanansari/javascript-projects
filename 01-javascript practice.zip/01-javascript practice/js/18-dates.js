var currentDate = new Date(); //current date
console.log("currentDate", currentDate);
var myENterDate = new Date(2018, 05, 12) // june month
console.log(myENterDate)
var method1 = new Date("2021-05-25T08:08:39.374Z"); // ISO format date time format may month
console.log("method1", method1);
var method2 = new Date("2019/05/31"); // ISO format only date format may month
console.log("method2", method2);
var method3 = new Date("05/25/2016"); // Short Date (MM/DD/YYYY)
console.log("method3", method3);
var method4 = new Date("May 15 2014"); // Long Date
console.log("method4", method4);
// var method5 = new Date(1464114600000);// time in  milisecond from 1970 to till 
// console.log("method5", method5); 


/*------------------------------------------------------------------------------------------------
day - start from 1 to 30/ 1 to 31/ 1 to 29/ 1 to 28
                                    0      1    2     3    4   5    6    7          8      9   10   11
month - month start from 0 to 11 [janauary,feb,march,april,may,june,july,august,september,oct,nov,december]

year - means year in YYYY format
-------------------------------------------------------------------------------------------*/

/*------------------------------------------------------------------------------------------------
            1-Date Methods
-------------------------------------------------------------------------------------------*/
var myDate = new Date();
var getDate = myDate.getDate();
var getMonth = myDate.getMonth() + 1; // month start from 0
var getYear = myDate.getFullYear();
var getTime = myDate.getTime() // from  1970 milisecond me dega time dega
var dateInString = myDate.toDateString() // Thu Oct 14 2021
var dateInIsoFormat = myDate.toISOString() // 2021-10-13T19:45:51.160Z
var dateInJson = myDate.toJSON() //2021-10-13T19:45:51.160Z
var localDate = myDate.toLocaleDateString()  // 10/14/2021  tumhare laptop/PC ki date utha kar dega
var localDateString = myDate.toLocaleString()  // 10/14/2021, 1:17:08 AM tumhare laptop/PC ki date & time utha kar dega
var localTimeString = myDate.toLocaleTimeString()  // 1:18:19 AM tumhare laptop/PC ka time utha kar dega
var dateINstrung2 = myDate.toString()       // Thu Oct 14 2021 01:19:19 GMT+0530 (India Standard Time)
var dateTimeString = myDate.toTimeString()  // 01:20:19 GMT+0530 (India Standard Time)
var utcTime = myDate.toUTCString()          // 01:20:19 GMT+0530 (India Standard Time)


// console.log(myDate);
// console.log("day", getDate)
// console.log("getMonth", getMonth)
// console.log("getYear", getYear)
// console.log("getTime", getTime)
// console.log("dateInString", dateInString)
// console.log("dateInIsoFormat", dateInIsoFormat)
// console.log("dateInJson", dateInJson)
// console.log("localDate", localDate)
// console.log("localDateString", localDateString)
// console.log("localTimeString", localTimeString)
// console.log("dateINstrung2", dateINstrung2)
// console.log("dateTimeString", dateTimeString)
// console.log("utcTime", utcTime)