
/*---------------------------------------------------------------------------
        1-Global Scope (access anywhere)
-----------------------------------------------------------------------------*/
//also we can manuplate global scope
// var apple;
// var apple = "hello Apple"
// var gScope = document.getElementById("gScope");
// gScope.addEventListener("click", function () {
//         apple = "hello new" // manuplate
//         // debugger
//         console.log("inside Apple", apple)
// })
// // debugger
// console.log("outside Apple", apple)


// /*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */

// /*---------------------------------------------------------------------------
//         2-Local Scope (not aaccessible out side thier scope)
// -----------------------------------------------------------------------------*/

// var myBtn = document.getElementById('myBtn')
// myBtn.addEventListener("click", function () {
//         var banana = "Hello Banana"

//         // debugger
//         // console.log("inside", banana)
// })
// debugger;
// console.log("outside", banana); // not accessibles
/*-------------------XXXXXXXX---END---XXXXXXXX-------------------------------- */

/*---------------------------------------------------------------------------
        Difference between var,let and const

        -before ES6 we are using only var
        -after ES6 there are more things invented which is known as
         let and const both are variables

         refence link :- https://www.freecodecamp.org/news/var-let-and-const-whats-the-difference/
-----------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
        1-Understanding var
        var ka scope either globally or locally scope
-----------------------------------------------------------------------------*/

//method 1 : local and global scope for var
var myVarGlobal = "hello " // scope global accessible anywhere
var gvar = document.getElementById("gvar");
gvar.addEventListener("click", function () {
        var myVarLocal = "local"; // local scope
        debugger
        console.log(myVarLocal) //acessible
        console.log(myVarGlobal) // accessible
})

console.log(myVarGlobal) // accessbile
// console.log(myVarLocal); // not accessbile

//method we can override var reassign kar skte hai
// var some = "hello"
// debugger
// var assignVar = document.getElementById("assignVar")
// assignVar.addEventListener("click", function () {
//         // some = "new"
//         // or
//         var some = "new" // declared variable with same name
// debugger
// console.log("reassing", some)
// })
// console.log("reassing", some)

//hoisting : all variables and funtions are moved to top;
// tumhara variable greeter naam se pahle hi register ho gaya greeter:undefined
//var declared kardiya top par value assign nhi kiya isliye undefined dikhata hai
// debugger
// console.log(greeter);
// var greeter = "say hello"
//output below type
// var greeter;
// console.log(greeter); // greeter is undefined
// greeter = "say hello"
//So var variables are hoisted to the top of their scope and initialized with a value of undefined.

/*---------------------------------------------------------------------------
        1-Understanding let
        let is block scope
-----------------------------------------------------------------------------*/

// method 1 : can not redeclared same variable name again


// var a = "jhscjh";
// var a = "jhbjhbjhb";
// debugger;
// console.log("a", a)
//above example error not thrown this problem solved by let and var goes to global scope.
// let a = "hjsbcvjhsd"
// let a = "nbsvbsdkc"
// debugger
// console.log("a", a)
// above example throws error as "Uncaught SyntaxError: Identifier 'a' has already been declared"
//let ka scope yaha par script rahega

// method 2 : using block statement
/*
{
    var b = 'kjkjnjk' // scope global
    debugger
    console.log('b', b) // accessible
}
debugger
console.log("b", b) // accessible

 in the above example var declared in block but its scope os global so we can access outside the block.
if we are using let then let will be block scope and cannot be accissble outside
 */

{
        // let b = "svbdcbsvdc" // scope block

        // debugger
        // console.log("b", b);
}
// debugger
// console.log("b", b);  //Uncaught ReferenceError: b is not defined


/*---------------------------------------------------------------------------
        1-Understanding const
        why const???
        let ke andar jo bhi issue the usko hatane ke liye const aaya.
-----------------------------------------------------------------------------*/
// let c = "nbsjsbdcj"
// c = 'saif'
// // debugger
// console.log("c", c)

// //in the above example we can reassgin value of variable c
// // but in const we cann't reasing
// const d = 'HJhjvhjv';
// // d = 'sameer'
// // debugger
// console.log("d", d); //Uncaught TypeError: Assignment to constant variable.

/*---------------------------------------------------------------------------
        conclusion
        1-var : global scope and local scope
        2-let : script scope and block scope
        3-const :script scope and block scope
-----------------------------------------------------------------------------*/


//consulsion 1 -we can do in var but cannot do in let
// var x = "jnbjhb";
// var x = 'hjbhjbsd'

// let y = "jhsbjshbcjhsbdc";
// // let y = "jsbsbvjsbcjjbs"; //Uncaught SyntaxError: Identifier 'a' has already been declared

// //consulsion 2 -but we can reassign value 
// var xx = "jhjbb"
// xx = "bhjbhjb"

// let yy = 'NBNJnbjhbhv'
// yy = "bsvfbnsbnsvcbn"

// // in the above example we can override value of let variable
// // but in case of const we can't override because it is more secure.
// let xxx = "nbsvbnsvdc";
// xxx = "ndbdcvnjsbvn";

// const yyy = "nbscnbscnjsd"
// yyy = 'nvbsvbs'; //Uncaught TypeError: Assignment to constant variable.





