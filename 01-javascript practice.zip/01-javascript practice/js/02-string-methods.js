var fullName = "My Name Is Momin Mohd. Saif Maqsood ahmed.";
console.log(fullName);

// 1. Length - returns the length of the string (number of characters)
console.log(fullName.length);

// 2. toUpperCase - returns the string in upper case (all characters)
console.log(fullName.toUpperCase());

// 3. toLowerCase - returns the string in lower case (all characters)
console.log(fullName.toLowerCase());

// 4. indexOf- returns the index of the first occurrence of the specified value in the string (number)
console.log(fullName.indexOf("Momin"));

// 5. lastIndexOf- returns the index of the last occurrence of the specified value in the string (number)
console.log(fullName.lastIndexOf("Momin"));

// 6. charAt- returns the character at the specified index (string)
console.log(fullName.charAt(8));

// 7. charCodeAt- returns the Unicode of the character at the specified index (number)
console.log(fullName.charCodeAt(8));

// 8. substring- returns the part of the string between the start and end indexes (start index included, end index excluded)
console.log("substring", fullName.substring(3, 9)); // substring(start, end)
console.log("substring", fullName.substring(9)); // from index 9

// 9. slice- returns the part of the string between the start and end indexes (start index included, end index included)
// negative indexing (start index included, end index included)
console.log("slice", fullName.slice(0, 9)); // slice(start, end)
console.log("slice", fullName.slice(9)); // from index 9
console.log("slice", fullName.slice(-10, -6)); // from index -10 to -6 count from right and extract

// 10. substr - same as slice but it doesn't accept negative index (start, length) length is optional.
console.log("substr", fullName.substr(3, 9)); // substr(start, length)
console.log("substr", fullName.substr(3)); // substr(start, length)

// 11. replace - replaces a specified value with another value in a string (search, replace)
console.log("replace", fullName.replace("Momin", "Ansari"));

// 12.replaceAll - replaces all occurrences of a specified value with another value in a string (search, replace)
console.log("replaceAll", fullName.replaceAll(" ", "-"));
console.log("replaceAll", fullName.replaceAll("M", "-"));
console.log("replaceAll", fullName.replaceAll("Momin", "-"));

// 13. trim - removes whitespace from both sides of a string
console.log("trim", fullName.trim());

// 14. split - splits a string into an array of substrings (separator) very important
console.log("split", fullName.split(" "));

// 15. includes - returns true if the string contains the specified value (search)
console.log("includes", fullName.includes("Momin")); // returns true
console.log("includes", fullName.includes("M")); // returns true
console.log("includes", fullName.includes("Z")); // returns false
console.log("includes", fullName.includes("Khan")); // returns false

// 16.search - returns the index of the first occurrence of the specified value in the string (search)
console.log("search", fullName.search("Momin")); // returns index of Momin



