const myDetailArry = [
    { id: 1, fName: "saif", salary: 20000 },
    { id: 2, fName: "sameer", salary: 32630 },
    { id: 3, fName: "nazim", salary: 25342 },
    { id: 4, fName: "naufil", salary: 47654 },
    { id: 5, fName: "bilal", salary: 22345 },
]


/*------------------------------------------------------------------------

        1-map method loop hi hai lekin isme hum konse array par kaam kar
         rahen hai wo bhi dedeta hai

----------------------------------------------------------------------------*/

myDetailArry.map(function (value, index, currArr) {
    console.log("value", value);
    console.log("index", index);
    console.log("currArr", currArr);
})

/*------------------------------------------------------------------------
    2-reduce method; calculation karne ke liye
----------------------------------------------------------------------------*/

//method 1 old method
let finalAmount = 0;

for (let i = 0; i < myDetailArry.length; i++) {

    let indivisualData = myDetailArry[i]
    let indivisualSalary = indivisualData.salary
    finalAmount += indivisualSalary
}

console.log(finalAmount);

let totalSalary = myDetailArry.reduce(function (preValue, currentValue) {
    return preValue + currentValue.salary;
}, 0);

console.log("total", totalSalary);

// 0+20000=20000
// 20000+32630=
//aise plus hote jayega


/*------------------------------------------------------------------------
    3-filter method return array jo bhi filter kiye hai wo usko ek new array me dedeta hai
----------------------------------------------------------------------------*/

let slectedEmployee = "sameer";

const filteredEmployee = myDetailArry.filter(function (value, index) {
    return value.fName === slectedEmployee

})
const salaryAbove30K = myDetailArry.filter(function (value, index) {
    return value.salary > 30000
})
console.log("filteredEmployee", filteredEmployee);
console.log("salaryAbove30K", salaryAbove30K);

const newSelectedEmployee = myDetailArry.find(function (value) {
    return value.fName === slectedEmployee
})
const newAbiveSalary = myDetailArry.find(function (value) {
    return value.salary > 30000
})
console.log("newSelectedEmployee", newSelectedEmployee);
console.log("newAbiveSalary", newAbiveSalary); // ek hi nikala 

/*------------------------------------------------------------------------
    3-find
    find bhi same hai filter ke jaisa lekin wo array nhi dega hume koi bhi ek value malum karni ho
    array of object me to wo ek value nikal kar deta hai,,iska matbal array nhi dega
----------------------------------------------------------------------------*/