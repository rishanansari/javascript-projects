/*------------------------------------------------------------------------------------------------
            1-Call method kis function me koi object ko access krna ho to call method se wo 
            object ko bhejenege aur  this se access karenge.
-------------------------------------------------------------------------------------------*/

//method 1 : normal
var personData = {
    firstName: "Momin",
    lastName: "saif"
}

var fullName = getFullName.call(personData)
console.log(fullName)
function getFullName() {
    console.log(this)
    return this.firstName + " " + this.lastName
}
//method 2 : object ke andar bhi call method apply kar skte hai.
var person = {
    age: 23,
    getAge: function () {
        return this.age;
    }
}

var person2 = { age: 54 };
var personAge = person.getAge.call(person2);  //agr person2 ki jagah person rakhege toh age 23 dikhayegi.
console.log("age", personAge);

//method 3
function saySomething(message, age) {
    return this.name + " is " + message + "and Age Is " + age;
}

var person4 = { name: "John" };

var saysomethinAsParameter = saySomething.call(person4, "awesome", 20);
console.log("saySomething", saysomethinAsParameter)

/*------------------------------------------------------------------------------------------------
        2- apply()

        The apply method is similar to the call() method. The only difference is that,

        call() method takes arguments separately whereas, apply() method takes arguments as an array.
-------------------------------------------------------------------------------------------*/

function saySomethingNew(message, age) {
    return this.name + " is " + message + "and Age Is " + age;
}

var person5 = { name: "John" };

var saysomethinAsParameterNew = saySomethingNew.apply(person5, ["awsome", 20]);
console.log("saySomething", saysomethinAsParameterNew)

/*------------------------------------------------------------------------------------------------
        3- Bind()

       bind method returned new function
-------------------------------------------------------------------------------------------*/

function getAge() {
    return `This is the age ${this.age}`
}

var ageNewObj = {
    age: 23
}

var outputAge = getAge.bind(ageNewObj);
var finalAge = outputAge()
//it returnes new function thats why we are store as variable but in that its new function 
//if we want output then you have to be call that variable as () eg outputAge()

console.log("outputAge", finalAge)