// var age = 21;
// var age = 28;
// var age = 55;
// var age = 100;
// if (age < 25) {
//     console.log("younger")
// } else if (age > 25 && age < 35) {
//     console.log("elder");
// } else if (age > 50 && age < 75) {
//     console.log("older");
// } else {
//     console.log("death");
// }    

//ternary
// age < 25 ? console.log("younger") : (age > 25 && age < 35) ? console.log("elder") : (age > 50 && age < 75) ? console.log("Older") : console.log("death");


/*------------------------------------------------------------------------
             agar bahot saari if else statement hai to if else ki jagah switch statement use karne ka
-------------------------------------------------------------------------*/
// var frendname = "Bilal";

// switch (frendname) {
//     case "saif":
//         console.log("one");
//         break;
//     case "Sameer":
//         console.log("two");
//         break;
//     case "Nazim":
//         console.log("three")
//         break;
//     case "Naufil":
//         console.log("Four")
//         break;
//     case "Bilal":
//         console.log("Five")
//         break;
//     case "Mohaddis":
//         console.log("Six")
//         break;
//     default:
//         console.log("No Number")
// }

// var age = 27;
// // var age = "fehege";
// switch (true) {
//     case (age < 25):
//         console.log("younger");
//         break;
//     case (age > 25):
//         console.log("Elder");
//         break;
//     case (age === 25):
//         console.log("twenty five");
//         break;
//     default:
//         console.log("nothing");
// }