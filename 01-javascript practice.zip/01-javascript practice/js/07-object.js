// why objects are used.
//diffrencence between array and object.

// how to make object
// method 1 : easy method
var mango = {
    type: "aapus",
    color: "yellow",
    fresh: true,
    qty: 1000,
    boxes: 10,
    perBox: 100
}

console.log("mango", mango)

//method 2
var apple = {}
apple.type = "kashmiri";
apple.color = "dark red";
apple.fresh = true;
apple.qty = 1000;
apple.boxes = 10;
apple.perBox = 100;

console.log("apple", apple)

//method 3
var banana = {}
banana["type"] = "Ilaichi";
banana["color"] = "yellow";
banana["fresh"] = true;
banana["qty"] = 1000;
banana["boxes"] = 10;
banana["perBox"] = 100;

console.log("banana", banana)




//how to access object

//method 1:
console.log(mango.type) // aapus
console.log(mango.color) // yellow
console.log(mango.fresh) // true

//method 2:

console.log(apple["type"]) // kashimiri
console.log(apple['color']) // dark red
console.log(apple[`fresh`]) // true



//nested Object

var personData = {
    firtName: "saif",
    age: 27,
    married: false,
    qualiFication: "graduate",
    family: {
        familyMember: 3,
        mother: {
            motherName: "Ruskhana",
            motherAge: 50,
            motherQualification: "SSC"
        },
        father: {
            fatherName: "Maqsood",
            fatherAge: 54,
            fatherQualification: "school"
        },
        brothersCount: 1,
        brothers: [
            { id: 1, brotherName: "kaif", brotherRelation: "Younger", brotherAge: 22, brotherQualification: "Graduate" },
        ],
        sistersCount: 0,
        sisters: []

    },
    totalFamilyCount: 4

}

console.log("personData", personData)
console.log("personData", personData.qualiFication)
console.log("personData", personData.family.father.fatherName)
console.log("personData", personData.family.brothers[0].brotherRelation)