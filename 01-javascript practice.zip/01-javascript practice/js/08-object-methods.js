/*------------------------------------------------------------------------
        1-convert object into array
-----------------------------------------------------------------------------*/

var bioData = {
    fullName: "Saif",
    bloodGroup: "A+ve",
    fatherName: "Maqsood",
    age: 26,
    qualification: "Graduate",
    nationality: "indian"
}

console.log(bioData)
console.log(typeof bioData)

//convert only keys in array
var keyArr = Object.keys(bioData);
console.log("key Array", keyArr)

//covert only values into array
var valueArr = Object.values(bioData)
console.log("value Array", valueArr)

//covert both keys and value inside one array i.e multidimensional array [[],[],[]]
var keyValueArr = Object.entries(bioData);
console.log("keyValueArr", keyValueArr);

/*--------XXXXXXXX---END---XXXXXXXX------------- */
/*------------------------------------------------------------------------
        2-Assign Method
-----------------------------------------------------------------------------*/
var a = {
    fisrtName: "saif",
    lastName: "Momin"
}
var b = {
    qualification: "graduate",
    age: 27
}
var mergedObj = Object.assign(a, b)
console.log("merge: ", mergedObj)
console.log("mnerge", mergedObj.fisrtName)
console.log("mnerge", mergedObj.qualification)

/*--------XXXXXXXX---END---XXXXXXXX------------- */

/*------------------------------------------------------------------------
        3-Object Method for doing some work by using anonymys function
-----------------------------------------------------------------------------*/
var myObj = {
    fisrtName: "Saif",
    lastName: "Momin",
    fullName: function () {
        // return this.fisrtName + " " + this.lastName
        return `${this.fisrtName} ${this.lastName}`
    }
}

var fullName = myObj.fullName()
console.log("fullName", fullName)
/*--------XXXXXXXX---END---XXXXXXXX------------- */


/*------------------------------------------------------------------------
        4-Object Method using getter function
-----------------------------------------------------------------------------*/

// dono method chal jayenge upar wala bhi aur ye wala bhi
var myObj1 = {
    fisrtName: "Saif",
    lastName: "Momin",
    get fullName() {
        return `${this.fisrtName} ${this.lastName}`
    }
}

var fullName = myObj1.fullName
console.log("fullName", fullName)


/*--------XXXXXXXX---END---XXXXXXXX------------- */


/*------------------------------------------------------------------------
        5-Object Method using setter function
-----------------------------------------------------------------------------*/
// normal method hard code but of we want diffrenet values according to conditions that's why we are using setter function
// var obj3 = {
//     fisrtName: "Saif",
//     lastName: "Momin",
// }
// obj3.qualification = "Gradute"

var obj3 = {
    fisrtName: "Saif",
    lastName: "Momin",
    qualification: "",
    set qulify(a) {
        console.log("qualifacation", a)
        this.qualification = a
    }
}
obj3.qulify = "Graduate"

console.log("obj3", obj3);

//excersice on setter
var btn1 = document.getElementById("btn1");
var btn2 = document.getElementById("btn2");
var btn3 = document.getElementById("btn3");
var btn4 = document.getElementById("btn4");

btn1.addEventListener("click", function () {
    // obj3.qualification = "SSC"
    obj3.qulify = "SSC"
    // console.log("obj3", obj3);
    console.log("btn1")

})
btn2.addEventListener("click", function () {
    console.log("btn2")
    // obj3.qualification = "HSC"
    obj3.qulify = "HSC"
    // console.log("obj3", obj3);
})
btn3.addEventListener("click", function () {
    console.log("btn3")
    // obj3.qualification = "Diploma"
    obj3.qulify = "Diploma"
    // console.log("obj3", obj3);

})
btn4.addEventListener("click", function () {
    console.log("btn4")
    // obj3.qualification = "Degree"
    // obj3.qulify = "Degree"
    console.log("obj3", obj3);

})
/*--------XXXXXXXX---END---XXXXXXXX------------- */


