var colllectionData = ["Bilal", "naufil", "sameer", "nazim"];
// console.log(colllectionData.length)
/*------------------------------------------------------------------------
             1-for loop (index par work karega)
-------------------------------------------------------------------------*/
for (let i = 0; i < colllectionData.length; i++) {
    // console.log(i)
    // console.log(colllectionData[i])
}

/*------------------------------------------------------------------------
             2-for of loop (value par work krege)
-------------------------------------------------------------------------*/
for (let data of colllectionData) {
    // console.log("for of", data)
}
/*------------------------------------------------------------------------
             3-forEach loop (value,index) array.forEach(function(value,index)=>{

             })
-------------------------------------------------------------------------*/
colllectionData.forEach(function (value, index,) {
    // console.log("foreach", value);
    // console.log("foreach", index);
})

/*------------------------------------------------------------------------
             4-map loop(mathod) (value,index,currentArray) array.map(function(value,index,currentArray)=>{

             })
             currentArray ko omit kar skte ho optional hai
-------------------------------------------------------------------------*/
colllectionData.map(function (value, index, currArry) {
    // console.log("value", value)
    // console.log("index", index)
    // console.log("current array", currArry) // samajhne ke liye hai tum konse array par kaam kar rahe ho?
})

/*------------------------------------------------------------------------
             5-deep dive in loop
-------------------------------------------------------------------------*/
// 1-for loop
var arrObjData = [
    { id: 1, fName: "bilal", age: 22, qualification: "Automobile" },
    { id: 2, fName: "Naufil", age: 21, qualification: "Computer" },
    { id: 1, fName: "Nazim", age: 23, qualification: "Civil" },
    { id: 1, fName: "Sameer", age: 26, qualification: "Mechanical" },
]
// console.log(arrObjData[0].fName)
// console.log(arrObjData[1].age);
// console.log(arrObjData.length)
for (let i = 0; i < arrObjData.length; i++) {
    // console.log(i)
    // console.log(arrObjData[i].qualification)
    // console.log(arrObjData[i].fName)
    // console.log(arrObjData[i].age)
}
// 2-for of loop
var arrObjData = [
    { id: 1, fName: "bilal", age: 22, qualification: "Automobile" },
    { id: 2, fName: "Naufil", age: 21, qualification: "Computer" },
    { id: 1, fName: "Nazim", age: 23, qualification: "Civil" },
    { id: 1, fName: "Sameer", age: 26, qualification: "Mechanical" },
]
for (let data of arrObjData) {
    // console.log("for of", data)
}
// 3-for each
var arrObjData = [
    { id: 1, fName: "bilal", age: 22, qualification: "Automobile" },
    { id: 2, fName: "Naufil", age: 21, qualification: "Computer" },
    { id: 1, fName: "Nazim", age: 23, qualification: "Civil" },
    { id: 1, fName: "Sameer", age: 26, qualification: "Mechanical" },
]

arrObjData.forEach(function (value, index) {
    // console.log("for each", value);
    // console.log("foreach", index);
})
// 4-map loop method
var arrObjData = [
    { id: 1, fName: "bilal", age: 22, qualification: "Automobile" },
    { id: 2, fName: "Naufil", age: 21, qualification: "Computer" },
    { id: 1, fName: "Nazim", age: 23, qualification: "Civil" },
    { id: 1, fName: "Sameer", age: 26, qualification: "Mechanical" },
]
arrObjData.map(function (value, index, currentArray) {
    // console.log("map", value);
    // console.log("map", index);
    // console.log("map", currentArray);
})
//dusre bhi loop run karna hai HW;
var newData = [
    { id: 1, fName: "bilal", age: 22, qualification: "Automobile", active: true },
    { id: 2, fName: "Naufil", age: 21, qualification: "Computer", active: false },
    { id: 1, fName: "Nazim", age: 23, qualification: "Civil", active: true },
    { id: 1, fName: "Sameer", age: 26, qualification: "Mechanical", active: false },
]
for (data of newData) {
    if (data.active === true) {
        console.log("true", data)
    }
    else {
        console.log("false", data);
    }
}



