// String
//change Name:-
// var myName = document.getElementById("myName")
// var changeName = "My Name Is Bilal";

// myName.innerHTML = changeName;
// console.log(myName.innerHTML)

//fullName:-
// var fullName = document.getElementById("fullName")
// var fname = "Momin Naufil";
// var lname = "Iqbal Ahmed";

// fullName.innerHTML = `My Name is ${fname} ${lname}`;
// // fullName.innerHTML = "My Name is " + fname + " " + lname;
// console.log(fullName.innerHTML)

// Number
// var myNumber = 10;
// var myNewNumber = 50.55;

// console.log(myNumber);
// console.log(myNewNumber);


//Array
// var myprofile = ["Nazim", `male`, 23, true]

// console.log(typeof myprofile)

// obeject
// var bike = {
//     company: "Suzuki",
//     modalName: "Hayabusa",
//     engineCapacity: "1100cc",
//     topSpeed: "299km/h",
//     noOfGear: 6,
//     color: "black",
// }
// console.log(bike)

// Array of object (means array k andar object. multiple object ko ek hi array me likh sakte hai bus har object k baad coma imp hai)

// var FlipkartProducts = [
//     {
//         id: "Samsung124", brand: "Samsung", Models: [
//             { modelId: "sam1", Model: "Note 6", color: ["red", "white", "black"] },
//             { modelId: "sam1", Model: "Note 7", color: ["red", "white", "black"] },
//             { modelId: "sam1", Model: "Note 8", color: ["red", "white", "black"] },
//             { modelId: "sam1", Model: "Note 9", color: ["red", "white", "black"] }


//         ]
//     },
//     {
//         id: "Apple229", brand: "Apple", Models: [
//             { modelId: "app1", Model: "iphone 6", color: ["red", "white", "black"] },
//             { modelId: "app2", Model: "iphone 7", color: ["red", "white", "black"] },
//             { modelId: "app3", Model: "iphone 8", color: ["red", "white", "black"] },
//             { modelId: "app4", Model: "iphone x", color: ["red", "white", "black"] }

//         ]
//     }

// ]
// console.log("FlipkartProducts", FlipkartProducts)
// console.log(typeof FlipkartProducts);

// numbers (" + , - , * , / ")
// var x = 20;
// var y = 5;

// var sumNumber = x + y;
// var sumNumber = x - y;
// var sumNumber = x / y;
// var sumNumber = x * y;
// var sumNumber = x % y;

// console.log(sumNumber)

//Array( collection of data)

// var myfrndcircle = document.getElementById("frndcircle")
// var friendsCircle = ["Mohaddis", "bilal", "Naufil", "Tauheed"]

// console.log(friendsCircle[0])
// console.log(friendsCircle[1])
// console.log(friendsCircle[2])
// console.log(friendsCircle[3] = "saif")
// console.log(friendsCircle)

// myfrndcircle.innerHTML = friendsCircle

// Convert Array into String 

// 1-to String method

// var fruits = ["Mango", "Apple", "Banana", "Orange"]
// var convertintostring = fruits.toString()

// console.log(fruits)
// console.log(typeof fruits)
// console.log(convertintostring)
// console.log(typeof convertintostring)

// 2-join method

// var fruits1 = ["Mango", "Apple", "Banana", "Orange"]
// // var convertIntoString1 = fruits1.join()        //mango,apple,banana,orange
// var convertIntoString1 = fruits1.join(" ")        //mango apple banana orange
// // var convertIntoString1 = fruits1.join("|")     //mango|apple|banana|orange

// console.log("join method:", convertIntoString1)
// console.log(typeof convertIntoString1)

// pop and push method remove and add at the last element of array
// 1-pop()

// var bikeCompanies = ["Honda", "TVS", "Hero", "Suzuki", "Bajaj", "Kawasaki"] //kawasaki remove
// var removeLastElemnt = bikeCompanies.pop()

// // console.log("pop", removeLastElemnt) //show which element is remove
// console.log("pop", bikeCompanies)    //show all element except kawasaki

// 2-push()

// var bikeCompanies2 = ["Honda", "TVS", "Hero", "Suzuki", "Bajaj", "Kawasaki"] //Ducati add at last after kawasaki
// var addLastElement = bikeCompanies2.push("Ducati")

// console.log("push", bikeCompanies2)

// Shift and unshift method remove and add at the fist element of array
// 1-Shift
/*
var bikeCompanies3 = ["Honda", "TVS", "Hero", "Suzuki", "Bajaj", "Kawasaki"] //Honda remove
var removeFirstElemnt = bikeCompanies3.shift()

console.log("Shift", bikeCompanies3)*/

// //2-unshift

// var bikeCompanies3 = ["Honda", "TVS", "Hero", "Suzuki", "Bajaj", "Kawasaki"] //BMW add before Honda
// var addFirstElemnt = bikeCompanies3.unshift("BMW")

// console.log("unShift", bikeCompanies3)

// // Splice method add and remove elements of array anyway

// var color = ["red", "black", "blue", "green", "yellow"]

// var splicemethod = color.splice(2)               //all are removed Excepting starting two element.
// var splicemethod = color.splice(2, 0, "pink")    //iska matlab 2 k baad (0)koi bhi remove na ho aur pink add hojaye.
// var splicemethod = color.splice(2, 2, "pink")       //iska matlab 2 k baad 2 element remove hojaye aur uski jagah pink add hojaye.

// console.log("splice", color)   //yaha main var mtlb color likhege

// // Slice method

// var color2 = ["red", "black", "blue", "green", "yellow"]
// // var sliceMethod = color2.slice(2)   //starting two are removing only
// var sliceMethod = color2.slice(1, 4)   //first element remove and after lenght of 4 all are removing

// console.log("slice", sliceMethod)  //yaha color2 nhi likhe balke second var ka naam dege.

//object
//how to make object
//method-1 easy method

// var bike = {
//     company: "suzuki",
//     modelName: "Acces125",
//     type: "mopet",
//     color: "blue",
//     engineCapacity: "125cc",
//     topSpeed: "100kmph",
//     mileage: "40kmpl",
// }

// console.log("object", bike);
// console.log(typeof bike);

// method-2 


// var apple = {}
// apple.type = "kashmiri";
// apple.color = "dark red";
// apple.fresh = true;
// apple.qty = 1000;
// apple.boxes = 10;
// apple.perBox = 100;

// console.log("apple", apple);
// console.log(typeof apple)

//method-3

// var banana = {}
// banana["type"] = "Ilaichi";
// banana["color"] = "yellow";
// banana["fresh"] = true;
// banana["qty"] = 1000;
// banana["boxes"] = 10;
// banana["perBox"] = 100;

// console.log("banana", banana)

// //how to access object

// //method 1:
// console.log(mango.type) // aapus
// console.log(mango.color) // yellow
// console.log(mango.fresh) // true

// //method 2:

// console.log(apple["type"]) // kashimiri
// console.log(apple['color']) // dark red
// console.log(apple[`fresh`]) // true

//nested obeject

// var personData = {
//     firstName: "Nazim",
//     lastName: "Ansari",
//     age: "23",
//     qualification: "Graduate",
//     family: {
//         familyMember: 4,
//         mother: {
//             Name: "Qaisar Jahan",
//             age: "43",
//             qualifucation: "10th",
//         },
//         father: {
//             Name: "Azeem",
//             age: "45",
//             qualification: "Teacher",
//         },
//         brotherCount: 1,
//         brother: [
//             { Name: "HUzaifa", age: "15", qualification: "Running 10th" },
//         ],
//         sisterCount: 1,
//         sister: [{ Name: "--", age: "22", qualification: "B.A" },
//         ],
//     },
//     totalFamilyMember: 5,

// }
// console.log("personData", personData);
// console.log(typeof personData);
// console.log(personData.family.father.qualification);
// console.log(typeof personData.family.father.qualification);

//convert object into array

// var bioData = {
//     fullName: "Saif",
//     bloodGroup: "A+ve",
//     fatherName: "Maqsood",
//     age: 26,
//     qualification: "Graduate",
//     nationality: "indian"
// }

// console.log(bioData)
// console.log(typeof bioData)

// //convert only keys into array

// var keyArry = Object.keys(bioData);
// console.log("keysInArray", keyArry);

// //convert only value into array

// var valueArray = Object.values(bioData);
// console.log("valueInArray", valueArray);

// //convert both in array

// var Both = Object.entries(bioData);
// console.log("both", Both);
//-----end-----//

//Assign method

// var a = {
//     Name: "Nazim",
//     age: "23",
// }
// var b = {
//     qualification: "Graduate",
//     stayIn: "Bhiwandi",
// }
// var mergeObe = Object.assign(a, b);
// console.log(mergeObe);

//--------end----------//

/*------------------------------------------------------------------------
        3-Object Method for doing some work by using anonymys function
-----------------------------------------------------------------------------*/
// var myobj3 = {
//     fName: "Nazim",
//     lName: "Ansari",

//     fullName: function () {
//         return `${this.fName} ${this.lName}`

//     }
// }
// var fullName = myobj3.fullName()
// console.log("fullname", fullName);

// 4-object method for doing getter function

// var myObjt = {
//     fName: "Nazim",
//     lName: "Ansari",

//     get fullName() {
//         return `${this.fName} ${this.lName}`
//     }
// }

// var fullName = myObjt.fullName
// console.log("fullName", fullName)

//practice

// var myobj4 = {
//     fName: "Nazim",
//     lName: "Ansari",

//     get fullName() {
//         return `${this.fName} ${this.lName}`
//     }
// }
// var fullName = myobj4.fullName
// console.log("fullName", fullName);

// var myobj3 = {
//     firstName: "Nazim",
//     lastName: "Ansari",

//     fullName: function () {
//         return `${this.firstName} ${this.lastName}`
//     }
// }
// var fullName = myobj3.fullName()
// console.log(fullName);

//--------end practice-------//

//setter function
// var object2 = {
//     fName: "Nazim",
//     lName: "Ansari",
//     qualification: "",

//     set qualify(a) {
//         console.log("qualification", a)
//         this.qualification = a
//     }
// }
// object2.qualify = "graduate"
// console.log("object2", object2);

// var object2 = {
//     fName: "Nazim",
//     lNAme: "Ansari",
//     qualification: "",

//     set qualify(b) {
//         console.log("qualification", b);
//         this.qualification = b
//     }
// }
// object2.qualify = "graduate";
// console.log("object2", object2);

//excersice on setter

// var btn1 = document.getElementById("btn1");
// var btn2 = document.getElementById("btn2");
// var btn3 = document.getElementById("btn3");
// var btn4 = document.getElementById("btn4");

// btn1.addEventListener("click", function () {
//     object2.qualification = "SSC"
//     // object2.qulify = "SSC"

//     console.log("obj3", object2);
//     console.log("btn1");
// })

//--------Class constructor------//

// class PersonData {
//     constructor(fName, lName, age) {
//         this.fName = fName;
//         this.lName = lName;
//         this.age = age;

//     }
// }

// var personData = new PersonData("Nazim", "Ansari", 23);

// var fullName = personData.fName + " " + personData.lName
// var age = `I am ${this.personData.age} old`

// console.log(fullName);
// console.log(age);

// practice
// simple class
// class PersonData {
//     constructor(fName, lName, age) {
//         this.fName = fName;
//         this.lName = lName;
//         this.age = age;

//     }

// }
// var persondata2 = new PersonData("Nazim", "Ansari", 23);
// var fullName = persondata2.fName + " " + persondata2.lName
// var age = `I am ${this.persondata2.age}`

// console.log(fullName);
// console.log(age);

//Simple class with method

// class PersonDataOne {
//     constructor(fName, lName, age) {
//         this.fName = fName;
//         this.lName = lName;
//         this.age = age;
//     }
//     getFullName() {
//         return this.fName + " " + this.lName
//     }
//     increasedPersonAge(iAgeValue, y) {
//         return this.age + iAgeValue - y;
//     }

// }
// var newPersonData = new PersonDataOne("Nazim", "Ansari", 23);
// var fullName = newPersonData.getFullName();
// var increasedAge = newPersonData.increasedPersonAge(20, 40);

// console.log("increasedAge", fullName, increasedAge);

//practice
// class Personprofile {
//     constructor(fName, lName, age) {
//         this.fName = fName;
//         this.lName = lName;
//         this.age = age;

//     }
//     getFullName() {
//         return this.fName + " " + this.lName
//     }
//     increasedPersonAge(iAge, y) {
//         return this.age + iAge - y;
//     }
// }

// var newPersonData = new Personprofile("Nazim", "Ansari", 23)
// var fullName = newPersonData.getFullName();
// var increasedAge = newPersonData.increasedPersonAge(20, 40)

// console.log("Personprofile", newPersonData);
// console.log("increasedAge", fullName, increasedAge);

//practice
// class PersonNormalData {
//     constructor(fName, lName, age) {
//         this.fName = fName;
//         this.lName = lName;
//         this.age = age;
//     }
//     getFullName() {
//         return this.fName + " " + this.lName
//     }
//     increasedAge(iAge, y) {
//         return this.age + iAge - y
//     }
// }

// var newPersonData = new PersonNormalData("Nazim", "Ansari", 23)
// var fullNAme = newPersonData.getFullName()
// var increasedPersonAge = newPersonData.increasedAge(20, 40)

// console.log("Personprofile", newPersonData);
// console.log("increasedPersonAge", fullNAme, increasedPersonAge);

//--------Again-Object-coonstructor------//

// function Persondata(fName, lName, age) {
//     this.fName = fName;
//     this.lName = lName;
//     this.age = age;
// }
// var persondata = new Persondata("Nazim", "Ansari", 23)
// var myName = new Persondata("Ansari", "Tauheed", 22)

// console.log("persondata", persondata);
// console.log("persondata", persondata.fName, persondata.lName, persondata.age);
// console.log("myName", myName.fName, myName.lName, myName.age);

// //practice

// function PersonDataTwo(fName, lName, age) {
//     this.fName = fName;
//     this.lName = lName;
//     this.age = age;

// }
// var newPersonData = new PersonDataTwo("Nazim", "Ansari", 23)
// newPersonData.qualification = "Graduate";

// console.log("newPersonData", newPersonData);
// console.log(newPersonData.fName, newPersonData.lName, newPersonData.age, newPersonData.qualification);

//-------operators---------//

var myNumber = 0;
var myDecNumber = 20;

var incbtn = document.getElementById("inc");
var decbtn = document.getElementById("dec");

incbtn.addEventListener("click", function () {

    // method:1
    // console.log("inc 1", myNumber++);  //start from 0

    //method:2
    // myNumber = myNumber + 1;
    // console.log("inc 2", myNumber); //start from 1

    //or

    // myNumber += 1;
    // console.log("inc3", myNumber);
})
decbtn.addEventListener("click", function () {
    // method:1
    // console.log("dec1", myDecNumber--); //decrement from 20

    // method:2
    // myDecNumber = myDecNumber - 1;
    // console.log("dec2", myDecNumber);  // decrement from 19

    //or
    myDecNumber -= 1;
    console.log("dec3", myDecNumber);
})

//=========================function===================//

// let personData = {
//     personName: "Nazim",
//     time: "11:00 AM",
//     travel: "Mumbai",
//     officeName: "IT solution",
// }

// nazimFn(personData.personName, personData.time, personData.travel, personData.officeName);

// let personName2 = "Naufil";
// let morningTime = "10:00 Am";
// let travell = "Thane";
// let officeName = "WebMD";

// nazimFn(personName2, morningTime, travell, officeName);

// nazimFn("Saif", "9 am", "Adaptive");

// function nazimFn(name, time, travel, officeName) {
//     console.log(`${name} Subha ${time} baje uthta hai.`);
//     console.log(`${name} roz ${travel} jata hai.`);
//     console.log(`${name} ki office ka naam ${officeName} hai.`);
// }

//practice

let personprofile = {
    personName1: "Nazim",
    morningTime: "10:00 am",
    travel: "Thane",
    officeName: "IT vedant",
}

ourFn(personprofile.personName1, personprofile.morningTime, personprofile.travel, personprofile.officeName);

let personName02 = "Naufil";
let morningTimes = "9:45 am";
let travel = "Aeroli";
let officeName = "WebMD";

ourFn(personName02, morningTimes, travel, officeName);

ourFn("Bilal", "11:00 am", "Andheri", "Buzzwork");

function ourFn(name, time, travel, officeName) {
    console.log(`${name} subha ${time} uththa hai.`);
    console.log(`Wo roz ${travel} job par jata hai.`);
    console.log(`Uski company ka naam ${officeName} hai.`);
}

/*------------------------------------------------------------------------------------------------
            2-Type Two special functions bolte hai qki ye kuch kaam karte hai aur kaam karne baad value ko return kar dete hai
-------------------------------------------------------------------------------------------*/

function getPercentage(ObtainedValue, totalValue) {
    let percentage = (ObtainedValue / totalValue) * 100
    return percentage
}

function resultDeclarationWithName(name, percentage) {
    return `Student ${name} got ${percentage}`
}

const studentsData = [
    { id: 1, studentName: "Nazim", obtainMarks: 746, totalMarks: 800 },
    { id: 2, studentName: "Bilal", obtainMarks: 696, totalMarks: 800 },
    { id: 3, studentName: "Naufil", obtainMarks: 730, totalMarks: 800 },
    { id: 4, studentName: "Sameer", obtainMarks: 656, totalMarks: 800 },
    { id: 5, studentName: "Mohaddis", obtainMarks: 700, totalMarks: 800 }
]

for (let i = 0; i < studentsData.length; i++) {
    let student = studentsData[i]
    let percentage = getPercentage(student.obtainMarks, student.totalMarks)
    let resultWithName = resultDeclarationWithName(student.studentName, percentage)
    console.log("result", resultWithName);

}

//practice

function getPercentage(obtmarks, totMarks) {
    let percentage = (obtmarks / totMarks) * 100
    return percentage
}

function resultWithName(name, percentage) {
    return `Student ${name} got ${percentage}`
}

const studentdetails = [
    { id: 1, studentName: "Nazim", obtainMarks: "888", totalMarks: "1000" },
    { id: 1, studentName: "Bilal", obtainMarks: "905", totalMarks: "1000" },
    { id: 1, studentName: "Naufil", obtainMarks: "950", totalMarks: "1000" },
    { id: 1, studentName: "Mohaddis", obtainMarks: "786", totalMarks: "1000" }
]

for (i = 0; i < studentdetails.length; i++) {
    let student = studentdetails[i];
    let percentage = getPercentage(student.obtainMarks, student.totalMarks);
    let resultWithNames = resultWithName(student.studentName, percentage)
    console.log(resultWithNames);
}

//practice

function getPercentage(obtainmarks, totalMarks) {
    let percentage = (obtainmarks / totalMarks) * 100
    return percentage
}
function resultWithName(name, percentage) {
    return `Student ${name} ${percentage}`
}

const studentsDatas = [
    { id: 1, studentName: "Saif", obtainMarks: "800", totalMarks: "950" },
    { id: 1, studentName: "Bilal", obtainMarks: "940", totalMarks: "950" },
    { id: 1, studentName: "Naufil", obtainMarks: "790", totalMarks: "950" }

]

for (i = 0; i < studentsDatas.length; i++) {
    let student = studentsDatas[i]
    let percentage = getPercentage(student.obtainMarks, student.totalMarks)
    let result = resultWithName(student.studentName, percentage)
    console.log(result);
}

//======================call,apply and bind method===================//

//1-call    method-1:normal

var person = {
    fName: "Nazim",
    lName: "Ansari",
}
var fullName = getFullName.call(person)
console.log(fullName);

function getFullName() {
    console.log(this);
    return this.fName + " " + this.lName
}

//method-2:  object ke under bhi call method apply kar sakte hai

var person2 = {
    fName: "Bilal",
    lName: "Momin",
    getFullName: function () {
        return this.fName + " " + this.lName
    }
}
var person3 = person2.getFullName.call(person2)
console.log(person3);




















//call-apply-bind

//method-1

// var persondata = {
//     firstName: "Mohd Nazim",
//     lastName: "Ansari"
// }
// var fullName = getFullName.call(persondata)
// console.log(fullName)

// function getFullName() {
//     console.log(this)
//     return this.firstName + " " + this.lastName
// }

//method-2

// var persondata2 = {
//     age: 23,
//     getAge: function () {
//         return this.age;
//     }
// }
// var person2 = { age: 50 };
// var personage = persondata2.getAge.call(person2)
// console.log("age", personage)

/* Object */
//method 1:

/*var bike = {
    modelName: "Kawasaki H2",
    color: "carbon black",
    engineCc: 998,
    power: "310 hp",
    topSpeed: "299 kmph"

}*/




